%% 
% Roland Meeks (2010-11)
%
% Given information on independent normal-Wishart prior distributions, OLS 
% parameter estimates, and data, uses Gibbs sampling to draw from the 
% posterior distributions B|Sigma and Sigma|B. Returns the draws, and
% functions of them such as impulse-responses.
function s = GetINWishartPosterior( prior, strols, p, post_options )
%% ====================== Initialization & Storage ========================

% Data & important constants of dimension
Y = strols.Y;
X = strols.X;
[ T M ] = size( Y );
K = size( X, 2 );
Z = kron( eye( M ), X );

% Check if BVAR includes an intercept
if ( K > M*p )
    constant = 1;
elseif ( K == M*p )
    constant = 0;
end;

% coefficient matrices from prior
a_prior = vec( prior.A_prior );
V_prior = prior.V_prior;

s = struct( 'A_post', [], 'V_post', [], 'v_post', [], 'S_post', [], ...
    'SIGMA_post', [], 'A_mean', [], 'IRF', [] );

% Initialize Bayesian posterior parameters using OLS values...
% Note that as we first draw from the conditional for alpha, we don't need
% to get an 'initial' alpha (if we were first drawing SIGMA, we would).
SIGMA = strols.SIGMA_OLS*(T-K)/(T-K+1); % n.b. check df?

% Storage space for posterior draws
ALPHA_draws = zeros(post_options.draws,K,M);
S_draws = zeros(post_options.draws,M,M);
SIGMA_draws = zeros(post_options.draws,M,M);

% Gibbs-related preliminaries
ntot = post_options.draws + post_options.burn;  % Total number of draws

%% ========================= Start Sampling ===============================
tic;

disp('Number of iterations');

drawcount = 0 ;
rejectcount = 0 ;
flag = 1;
imp = zeros( post_options.draws, M, M, post_options.irf_horizon );

% Gibbs sampler
while ( drawcount < ntot+1 )
    
    if ( (1 == flag) && (0 == mod(drawcount,post_options.it_print) ) )
        disp( [ 'Iteration = ' num2str( drawcount ) ]);
        toc;
    end
    
    %% (1) The ALPHA|SIGMA block -------------------------------------------
    VARIANCE = kron(inv(SIGMA),eye(T));
    V_post = inv(inv(V_prior) + Z'*VARIANCE*Z);
    a_post = V_post*( (V_prior\a_prior) + Z'*VARIANCE*Y(:)); % RM replaced inv(V)*a
    alpha = a_post + chol(V_post)'*randn(K*M,1); % Draw of alpha 
    
    ALPHA = reshape(alpha,K,M); % Draw of ALPHA
    
    %% (2) Reject unstable draws ... see Cogley & Sargent ("Evolving
    % Post-WWII US Inflation Dynamics") for a formal justification of the
    % procedure below in terms of rejection sampling where the 'full'
    % posterior (what they call the 'virtual' posterior) density is the
    % proposal distribution.
    
    % The companion form of the VAR AR coefficient matrices...
    COMP = [ ALPHA( constant+1:end, : )'; eye( M*(p-1) ), zeros( M*(p-1), M ) ];
    
    
    % Check the roots of the companion matrix, noting draws that violate
    % stationarity condition
    if ( (post_options.reject_nonstationary) && ...
                            ( any( abs( eig( COMP ) ) > 1.001 ) ) )
        flag = 0;
        rejectcount = rejectcount+1;
    else
        flag = 1;
    end;
    % --------------------------------------------------------------------
    % Draws that are non-stationary are rejected, as flag above is set to
    % zero. Just skip the draw of SIGMA, and go back to (1), where a new
    % ALPHA is gotten.
    
    %% (3) Posterior of SIGMA|ALPHA,Data ~ iW(inv(S_post),v_post)
    if ( 1 == flag )
        v_post = T + prior.v_prior; % note: does not change on iteration
        S_post = prior.S_prior + (Y - X*ALPHA)'*(Y - X*ALPHA);
        SIGMA = inv(wish(inv(S_post),v_post));% Draw SIGMA

        % (4) Store results for every iteration in excess of drawcount
        if drawcount > post_options.burn               
            % =========IMPULSE RESPONSES:
            %Btemp = reshape( ALPHA, constant+M*p, M );
            Btemp = ALPHA(constant+1:end,:);
            imp_resp = impulse( reshape( Btemp', M, M, p ), ...
                                 chol( SIGMA ), post_options.irf_horizon );
            imp(drawcount-post_options.burn,:,:,:) = imp_resp ;

            % ----- Save draws of the parameters
            ALPHA_draws(drawcount-post_options.burn,:,:) = ALPHA;
            S_draws(drawcount-post_options.burn,:,:) = S_post;
            SIGMA_draws(drawcount-post_options.burn,:,:) = SIGMA;

        end % end saving results
    end; % end if non-stationary flag is zero
    
    drawcount = drawcount + flag;
end; %end the main Gibbs for loop

disp( 'Done with Gibbs sampler' );
disp( ['Rejected ' num2str( 100*rejectcount/(rejectcount+ntot) ) ...
                                        '% of draws as non-stationary.'] )

toc;
%% ===================== End Sampling Posteriors ==========================

s.A_post = ALPHA_draws;
s.V_post = [];
s.S_post = S_draws;
s.v_post = v_post;
s.A_mean = squeeze( mean( ALPHA_draws ) ); % BUGBUG check
s.SIGMA_post = SIGMA_draws;
s.IRF = imp;

end